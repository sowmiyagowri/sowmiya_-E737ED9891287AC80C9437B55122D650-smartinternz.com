for i in range(1,10):
  for j in range(0,i):
     print(i,end="")
  print("/n")